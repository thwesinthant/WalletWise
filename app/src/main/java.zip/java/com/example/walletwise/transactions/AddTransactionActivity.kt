package com.example.walletwise.transactions

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.lifecycleScope
import com.example.walletwise.R
import com.example.walletwise.category.SelectCategoryActivity
import com.example.walletwise.database.AppDatabase
import com.example.walletwise.entity.Account
import com.example.walletwise.entity.CategoryEntity
import com.example.walletwise.entity.Notification
import com.example.walletwise.entity.Transaction
import com.google.android.material.button.MaterialButton
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID
import com.example.walletwise.category.getCategoryIconRes

class AddTransactionActivity : AppCompatActivity() {

    // ============================================================
    // DATABASE
    // ============================================================

    private lateinit var database: AppDatabase

    // ============================================================
    // USER
    // ============================================================

    private var currentUserId: Int = -1
    private var userCurrency: String = "MMK"

    // ============================================================
    // TRANSACTION STATE
    // ============================================================

    private var isExpense = true
    private var isTransfer = false
    private var currentAmountStr = ""

    private var editingTransactionId: Int = -1
    private var isEditMode = false

    private var editingCreatedAt: Long = 0L
    private var editingTransferGroupId: String? = null

    // ============================================================
    // CATEGORY
    // ============================================================

    private var selectedCategoryId: Long? = null
    private var selectedCategoryLabel = ""
    private var selectedCategoryIconRes: Int = 0


    private var categoryList: List<CategoryEntity> = emptyList()

    private lateinit var categoryChipContainer: LinearLayout
    private lateinit var categoryScroll: HorizontalScrollView
    private lateinit var tvSelectedCategory: TextView

    // ============================================================
    // SOURCE ACCOUNT
    // ============================================================

    private var selectedAccountId: Int? = null
    private var accountList: List<Account> = emptyList()

    private lateinit var paymentChipContainer: LinearLayout

    // ============================================================
    // DESTINATION ACCOUNT
    // ============================================================

    private var selectedDestinationAccountId: Int? = null

    private lateinit var destinationAccountChipContainer: LinearLayout
    private lateinit var destinationAccountScroll: HorizontalScrollView

    // ============================================================
    // VIEWS
    // ============================================================

    private lateinit var tvAmount: EditText
    private lateinit var tvExpense: TextView
    private lateinit var tvIncome: TextView
    private lateinit var tvTransfer: TextView

    private lateinit var btnAdd: MaterialButton
    private lateinit var etNote: EditText
    private lateinit var tvTitle: TextView
    private lateinit var tvDestinationLabel: TextView

    // ============================================================
    // INTENT EXTRA
    // ============================================================

    companion object {

        const val EXTRA_USER_ID = "USER_ID"
        const val EXTRA_TRANSACTION_ID = "TRANSACTION_ID"
    }

    // ============================================================
    // CATEGORY RESULT
    // ============================================================

    private val selectCategoryLauncher =
        registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) { result ->

            if (
                result.resultCode == RESULT_OK &&
                result.data != null
            ) {

                val categoryId =
                    result.data?.getLongExtra(
                        SelectCategoryActivity.RESULT_CATEGORY_ID,
                        -1L
                    ) ?: -1L

                val categoryLabel =
                    result.data?.getStringExtra(
                        SelectCategoryActivity.RESULT_CATEGORY_LABEL
                    )

                val categoryIcon =
                    result.data?.getIntExtra(
                        SelectCategoryActivity.RESULT_CATEGORY_ICON,
                        0
                    ) ?: 0

                if (
                    categoryId != -1L &&
                    !categoryLabel.isNullOrEmpty()
                ) {

                    selectedCategoryId =
                        categoryId

                    selectedCategoryLabel =
                        categoryLabel

                    selectedCategoryIconRes =
                        categoryIcon

                    updateSelectedCategoryText()

                    updateCategoryChips()
                }
            }
        }

    // ============================================================
    // ON CREATE
    // ============================================================

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)

        enableEdgeToEdge()

        setContentView(
            R.layout.activity_add_transaction
        )

        tvAmount = findViewById(R.id.tvAmount)

        tvAmount.isFocusable = true
        tvAmount.isFocusableInTouchMode = true

// Amount uses the custom keypad, not the phone keyboard
        tvAmount.showSoftInputOnFocus = false

// Cursor should be visible
        tvAmount.setCursorVisible(true)

// Give Amount focus
        tvAmount.requestFocus()

// Put cursor at the end
        tvAmount.setSelection(tvAmount.text.length)

// Prevent the system keyboard from opening initially
        window.setSoftInputMode(
            android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN
        )

        // ========================================================
        // WINDOW INSETS
        // ========================================================

        ViewCompat.setOnApplyWindowInsetsListener(
            findViewById(R.id.main)
        ) { view, insets ->

            val systemBars =
                insets.getInsets(
                    WindowInsetsCompat.Type.systemBars()
                )

            view.setPadding(
                systemBars.left,
                systemBars.top,
                systemBars.right,
                systemBars.bottom
            )

            insets
        }

        // ========================================================
        // DATABASE
        // ========================================================

        database =
            AppDatabase.getDatabase(this)

        // ========================================================
        // USER
        // ========================================================

        currentUserId =
            intent.getIntExtra(
                EXTRA_USER_ID,
                -1
            )

        if (currentUserId == -1) {

            Toast.makeText(
                this,
                "User session not found",
                Toast.LENGTH_LONG
            ).show()

            finish()
            return
        }

        // ========================================================
        // EDIT MODE
        // ========================================================

        editingTransactionId =
            intent.getIntExtra(
                EXTRA_TRANSACTION_ID,
                -1
            )

        isEditMode =
            editingTransactionId != -1

        // ========================================================
        // FIND VIEWS
        // ========================================================

        val btnBack =
            findViewById<ImageView>(
                R.id.btnBack
            )


        tvExpense =
            findViewById(
                R.id.tvExpense
            )

        tvIncome =
            findViewById(
                R.id.tvIncome
            )

        tvTransfer =
            findViewById(
                R.id.tvTransfer
            )

        btnAdd =
            findViewById(
                R.id.btnAdd
            )

        etNote =
            findViewById(
                R.id.etNote
            )

        categoryChipContainer =
            findViewById(
                R.id.categoryChipContainer
            )

        tvSelectedCategory =
            findViewById(
                R.id.tvSelectedCategory
            )

        tvTitle =
            findViewById(
                R.id.tvTitle
            )

        paymentChipContainer =
            findViewById(
                R.id.paymentChipContainer
            )

        tvDestinationLabel =
            findViewById(
                R.id.tvDestinationLabel
            )

        destinationAccountChipContainer =
            findViewById(
                R.id.destinationAccountChipContainer
            )

        // IMPORTANT:
        // This is the parent HorizontalScrollView.
        // The previous version only changed the child's visibility.
        destinationAccountScroll =
            findViewById(
                R.id.destinationAccountScroll
            )

        categoryScroll =
            findViewById(
                R.id.categoryScroll
            )

        // ========================================================
        // BACK
        // ========================================================

        btnBack.setOnClickListener {
            finish()
        }

        // ========================================================
        // INITIAL UI
        // ========================================================

        loadUserCurrency()

        updateAmountDisplay()

        updateSelectedCategoryText()

        setupTypeSelector()

        setupCategoryChips()

        setupPaymentChips()

        setupCustomKeypad()

        // ========================================================
        // EDIT / ADD
        // ========================================================

        if (isEditMode) {

            tvTitle.text =
                "Edit Transaction"

            loadTransactionForEditing()

        } else {

            tvTitle.text =
                "Add Expense"
        }

        // ========================================================
        // SAVE / UPDATE
        // ========================================================

        btnAdd.setOnClickListener {

            if (isEditMode) {

                if (isTransfer) {

                    updateTransfer()

                } else {

                    updateTransaction()
                }

            } else {

                if (isTransfer) {

                    saveTransfer()

                } else {

                    saveTransactionAndNotify()
                }
            }
        }
    }

    // ============================================================
    // LOAD USER CURRENCY
    // ============================================================

    private fun loadUserCurrency() {

        lifecycleScope.launch {

            database
                .userDao()
                .getUserById(currentUserId)
                .collect { user ->

                    user ?: return@collect

                    userCurrency =
                        user.currency

                    updateAmountDisplay()
                }
        }
    }

    // ============================================================
    // TYPE SELECTOR
    // ============================================================

    private fun setupTypeSelector() {

        tvExpense.setOnClickListener {

            isExpense = true
            isTransfer = false

            updateTypeUI()
        }

        tvIncome.setOnClickListener {

            isExpense = false
            isTransfer = false

            updateTypeUI()
        }

        tvTransfer.setOnClickListener {

            isExpense = false
            isTransfer = true

            updateTypeUI()
        }

        updateTypeUI()
    }

    // ============================================================
    // TYPE UI
    // ============================================================

    private fun updateTypeUI() {

        tvExpense.background = null
        tvIncome.background = null
        tvTransfer.background = null

        tvExpense.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.neutral_500
            )
        )

        tvIncome.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.neutral_500
            )
        )

        tvTransfer.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.neutral_500
            )
        )

        when {

            // ====================================================
            // TRANSFER
            // ====================================================

            isTransfer -> {

                tvTransfer.setBackgroundResource(
                    R.drawable.selector_selected_bg
                )

                tvTransfer.setTextColor(
                    ContextCompat.getColor(
                        this,
                        R.color.neutral_0
                    )
                )

                tvDestinationLabel.visibility =
                    View.VISIBLE

                // IMPORTANT:
                // Show the HorizontalScrollView, not only
                // destinationAccountChipContainer.
                destinationAccountScroll.visibility =
                    View.VISIBLE

                categoryScroll.visibility =
                    View.GONE

                tvSelectedCategory.visibility =
                    View.GONE

                btnAdd.text =
                    if (isEditMode) {
                        "Update Transfer"
                    } else {
                        "Transfer Money"
                    }

                updateDestinationAccountChips()
            }

            // ====================================================
            // EXPENSE
            // ====================================================

            isExpense -> {

                tvExpense.setBackgroundResource(
                    R.drawable.selector_selected_bg
                )

                tvExpense.setTextColor(
                    ContextCompat.getColor(
                        this,
                        R.color.neutral_0
                    )
                )

                tvDestinationLabel.visibility =
                    View.GONE

                destinationAccountScroll.visibility =
                    View.GONE

                categoryScroll.visibility =
                    View.VISIBLE

                tvSelectedCategory.visibility =
                    View.VISIBLE

                btnAdd.text =
                    if (isEditMode) {
                        "Update Expense"
                    } else {
                        "Add Expense"
                    }
            }

            // ====================================================
            // INCOME
            // ====================================================

            else -> {

                tvIncome.setBackgroundResource(
                    R.drawable.selector_selected_bg
                )

                tvIncome.setTextColor(
                    ContextCompat.getColor(
                        this,
                        R.color.neutral_0
                    )
                )

                tvDestinationLabel.visibility =
                    View.GONE

                destinationAccountScroll.visibility =
                    View.GONE

                categoryChipContainer.visibility =
                    View.VISIBLE

                categoryScroll.visibility =
                    View.VISIBLE

                tvSelectedCategory.visibility =
                    View.VISIBLE

                btnAdd.text =
                    if (isEditMode) {
                        "Update Income"
                    } else {
                        "Add Income"
                    }
            }
        }
    }

    // ============================================================
    // SAVE TRANSFER
    // ============================================================

    private fun saveTransfer() {

        val amount =
            currentAmountStr.toDoubleOrNull()

        // ========================================================
        // VALIDATE AMOUNT
        // ========================================================

        if (
            amount == null ||
            amount <= 0.0
        ) {

            Toast.makeText(
                this,
                "Please enter an amount greater than 0",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        // ========================================================
        // VALIDATE SOURCE
        // ========================================================

        if (selectedAccountId == null) {

            Toast.makeText(
                this,
                "Please select the source account",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        // ========================================================
        // VALIDATE DESTINATION
        // ========================================================

        if (selectedDestinationAccountId == null) {

            Toast.makeText(
                this,
                "Please select the destination account",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        // ========================================================
        // SAME ACCOUNT
        // ========================================================

        if (
            selectedAccountId ==
            selectedDestinationAccountId
        ) {

            Toast.makeText(
                this,
                "Source and destination accounts must be different",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        lifecycleScope.launch(Dispatchers.IO) {

            try {

                val sourceAccount =
                    database
                        .accountDao()
                        .getAccountBalanceById(
                            selectedAccountId!!,
                            currentUserId
                        )

                if (sourceAccount == null) {

                    withContext(Dispatchers.Main) {

                        Toast.makeText(
                            this@AddTransactionActivity,
                            "Source account not found",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                    return@launch
                }

                // =================================================
                // INSUFFICIENT BALANCE
                // =================================================

                if (
                    sourceAccount.currentBalance < amount
                ) {

                    withContext(Dispatchers.Main) {

                        Toast.makeText(
                            this@AddTransactionActivity,
                            "Insufficient balance in ${sourceAccount.name}",
                            Toast.LENGTH_LONG
                        ).show()
                    }

                    return@launch
                }

                val destinationAccount =
                    database
                        .accountDao()
                        .getAccountById(
                            selectedDestinationAccountId!!,
                            currentUserId
                        )

                if (destinationAccount == null) {

                    withContext(Dispatchers.Main) {

                        Toast.makeText(
                            this@AddTransactionActivity,
                            "Destination account not found",
                            Toast.LENGTH_SHORT
                        ).show()
                    }

                    return@launch
                }

                val note =
                    etNote.text
                        .toString()
                        .trim()

                val now =
                    System.currentTimeMillis()

                // =================================================
                // SAME GROUP ID FOR BOTH TRANSACTIONS
                // =================================================

                val transferGroupId =
                    UUID.randomUUID().toString()

                // =================================================
                // SOURCE TRANSACTION
                // =================================================

                val transferOut =
                    Transaction(

                        transactionId = 0,

                        userId =
                            currentUserId,

                        title =
                            if (note.isNotEmpty()) {
                                note
                            } else {
                                "Transfer to ${destinationAccount.name}"
                            },

                        amount =
                            amount,

                        type =
                            "TRANSFER_OUT",

                        categoryId =
                            null,

                        accountId =
                            selectedAccountId,

                        note =
                            note.ifEmpty {
                                "Transfer to ${destinationAccount.name}"
                            },

                        createdAt =
                            now,

                        transferGroupId =
                            transferGroupId
                    )

                // =================================================
                // DESTINATION TRANSACTION
                // =================================================

                val transferIn =
                    Transaction(

                        transactionId = 0,

                        userId =
                            currentUserId,

                        title =
                            "Transfer from ${sourceAccount.name}",

                        amount =
                            amount,

                        type =
                            "TRANSFER_IN",

                        categoryId =
                            null,

                        accountId =
                            selectedDestinationAccountId,

                        note =
                            note.ifEmpty {
                                "Transfer from ${sourceAccount.name}"
                            },

                        createdAt =
                            now,

                        transferGroupId =
                            transferGroupId
                    )

                // =================================================
                // INSERT BOTH
                // =================================================

                database
                    .transactionDao()
                    .insertTransfer(
                        transferOut,
                        transferIn
                    )

                // =================================================
                // NOTIFICATION
                // =================================================

                val notification =
                    Notification(

                        notificationId = 0,

                        userId =
                            currentUserId,

                        title =
                            "Money Transferred",

                        message =
                            "$userCurrency $amount transferred from ${sourceAccount.name} to ${destinationAccount.name}.",

                        type =
                            "TRANSFER",

                        referenceType =
                            "TRANSFER",

                        referenceId =
                            null,

                        isRead =
                            false,

                        timeAgo =
                            null,

                        createdAt =
                            now.toString()
                    )

                database
                    .notificationDao()
                    .insertNotification(
                        notification
                    )

                withContext(Dispatchers.Main) {

                    Toast.makeText(
                        this@AddTransactionActivity,
                        "Transfer completed successfully!",
                        Toast.LENGTH_SHORT
                    ).show()

                    finish()
                }

            } catch (e: Exception) {

                e.printStackTrace()

                withContext(Dispatchers.Main) {

                    Toast.makeText(
                        this@AddTransactionActivity,
                        "Error transferring money: ${e.localizedMessage}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    // ============================================================
    // PAYMENT / SOURCE ACCOUNT OBSERVER
    // ============================================================

    private fun setupPaymentChips() {

        lifecycleScope.launch {

            database
                .accountDao()
                .getAccountsForUser(
                    currentUserId
                )
                .collectLatest { accounts ->

                    accountList =
                        accounts

                    if (
                        selectedAccountId != null &&
                        accountList.none {
                            it.accountId ==
                                    selectedAccountId
                        }
                    ) {

                        selectedAccountId =
                            null
                    }

                    if (
                        selectedDestinationAccountId != null &&
                        accountList.none {
                            it.accountId ==
                                    selectedDestinationAccountId
                        }
                    ) {

                        selectedDestinationAccountId =
                            null
                    }

                    updatePaymentChips()

                    updateDestinationAccountChips()
                }
        }
    }

    // ============================================================
    // SOURCE ACCOUNT CHIPS
    // ============================================================

    private fun updatePaymentChips() {

        paymentChipContainer.removeAllViews()

        if (accountList.isEmpty()) {

            val text =
                TextView(this)

            text.text =
                "No payment accounts available"

            text.textSize =
                14f

            text.setTextColor(
                ContextCompat.getColor(
                    this,
                    R.color.neutral_500
                )
            )

            paymentChipContainer.addView(
                text
            )

            return
        }

        accountList.forEach { account ->

            paymentChipContainer.addView(
                createSourceAccountChip(
                    account
                )
            )
        }
    }

    // ============================================================
    // SOURCE ACCOUNT CHIP
    // ============================================================

    private fun createSourceAccountChip(
        account: Account
    ): LinearLayout {

        val chip =
            LinearLayout(this)

        chip.orientation =
            LinearLayout.HORIZONTAL

        chip.gravity =
            Gravity.CENTER_VERTICAL

        chip.setPadding(
            dpToPx(14),
            dpToPx(10),
            dpToPx(14),
            dpToPx(10)
        )

        chip.setBackgroundResource(
            R.drawable.chip_bg
        )

        val params =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

        params.marginEnd =
            dpToPx(10)

        chip.layoutParams =
            params

        val icon =
            TextView(this)

        icon.text =
            getAccountEmoji(
                account.name
            )

        icon.textSize =
            16f

        val text =
            TextView(this)

        val textParams =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

        textParams.marginStart =
            dpToPx(8)

        text.layoutParams =
            textParams

        text.text =
            account.name

        text.textSize =
            14f

        text.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.primary_900
            )
        )

        chip.alpha =
            if (
                selectedAccountId == null ||
                selectedAccountId == account.accountId
            ) {
                1.0f
            } else {
                0.5f
            }

        chip.setOnClickListener {

            selectedAccountId =
                account.accountId

            // If the selected source is the same as the
            // currently selected destination, clear destination.
            if (
                selectedDestinationAccountId ==
                selectedAccountId
            ) {

                selectedDestinationAccountId =
                    null
            }

            updatePaymentChips()

            updateDestinationAccountChips()
        }

        chip.addView(icon)
        chip.addView(text)

        return chip
    }

    // ============================================================
    // DESTINATION ACCOUNT CHIPS
    // ============================================================

    private fun updateDestinationAccountChips() {

        destinationAccountChipContainer.removeAllViews()

        if (accountList.isEmpty()) {
            return
        }

        accountList
            .filter {
                it.accountId != selectedAccountId
            }
            .forEach { account ->

                destinationAccountChipContainer.addView(
                    createDestinationAccountChip(
                        account
                    )
                )
            }
    }

    // ============================================================
    // DESTINATION ACCOUNT CHIP
    // ============================================================

    private fun createDestinationAccountChip(
        account: Account
    ): LinearLayout {

        val chip =
            LinearLayout(this)

        chip.orientation =
            LinearLayout.HORIZONTAL

        chip.gravity =
            Gravity.CENTER_VERTICAL

        chip.setPadding(
            dpToPx(14),
            dpToPx(10),
            dpToPx(14),
            dpToPx(10)
        )

        chip.setBackgroundResource(
            R.drawable.chip_bg
        )

        val params =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

        params.marginEnd =
            dpToPx(10)

        chip.layoutParams =
            params

        val icon =
            TextView(this)

        icon.text =
            getAccountEmoji(
                account.name
            )

        icon.textSize =
            16f

        val text =
            TextView(this)

        val textParams =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

        textParams.marginStart =
            dpToPx(8)

        text.layoutParams =
            textParams

        text.text =
            account.name

        text.textSize =
            14f

        text.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.primary_900
            )
        )

        chip.alpha =
            if (
                selectedDestinationAccountId ==
                account.accountId
            ) {
                1.0f
            } else {
                0.65f
            }

        chip.setOnClickListener {

            selectedDestinationAccountId =
                account.accountId

            updateDestinationAccountChips()
        }

        chip.addView(icon)
        chip.addView(text)

        return chip
    }

    // ============================================================
    // ACCOUNT EMOJI
    // ============================================================

    private fun getAccountEmoji(
        accountName: String
    ): String {

        val name =
            accountName.lowercase()

        return when {

            name.contains("cash") ->
                "💵"

            name.contains("card") ||
                    name.contains("visa") ||
                    name.contains("master") ->
                "💳"

            name.contains("bank") ||
                    name.contains("kbz") ->
                "🏦"

            name.contains("wallet") ||
                    name.contains("wave") ->
                "👛"

            else ->
                "💰"
        }
    }

    // ============================================================
    // CATEGORY OBSERVER
    // ============================================================

    private fun setupCategoryChips() {

        lifecycleScope.launch {

            database
                .categoryDao()
                .observeAll(
                    currentUserId
                )
                .collectLatest { categories ->

                    categoryList =
                        categories

                    if (
                        isEditMode &&
                        selectedCategoryId != null &&
                        selectedCategoryLabel.isEmpty()
                    ) {

                        selectedCategoryLabel =
                            categoryList
                                .firstOrNull {
                                    it.id ==
                                            selectedCategoryId
                                }
                                ?.label
                                ?: ""
                    }

                    updateSelectedCategoryText()
                    updateCategoryChips()
                }
        }
    }

    // ============================================================
    // CATEGORY CHIPS
    // ============================================================
    private fun updateCategoryChips() {

        categoryChipContainer.removeAllViews()

        val displayCategories =
            mutableListOf<CategoryEntity>()

        // ========================================================
        // FIND SELECTED CATEGORY
        // ========================================================

        val selectedCategoryEntity =
            categoryList.firstOrNull {
                it.id == selectedCategoryId
            }

        // ========================================================
        // ADD SELECTED CATEGORY FIRST
        // ========================================================

        if (selectedCategoryEntity != null) {

            displayCategories.add(
                selectedCategoryEntity
            )

            selectedCategoryLabel =
                selectedCategoryEntity.label

            selectedCategoryIconRes =
                getCategoryIconRes(
                    selectedCategoryEntity.iconName
                )
        }

        // ========================================================
        // ADD OTHER CATEGORIES
        // ========================================================

        categoryList
            .filter {
                it.id != selectedCategoryId
            }
            .take(
                if (selectedCategoryEntity != null) {
                    2
                } else {
                    3
                }
            )
            .forEach { category ->

                displayCategories.add(
                    category
                )
            }

        // ========================================================
        // CREATE CATEGORY CHIPS
        // ========================================================

        displayCategories.forEach { category ->

            categoryChipContainer.addView(
                createCategoryChip(
                    category
                )
            )
        }

        // ========================================================
        // OTHER BUTTON
        // ========================================================

        val otherChip =
            createOtherChip()

        otherChip.setOnClickListener {

            openCategorySelector()
        }

        categoryChipContainer.addView(
            otherChip
        )
    }


    // ============================================================
    // CATEGORY CHIP
    // ============================================================
    private fun createCategoryChip(
        category: CategoryEntity
    ): LinearLayout {

        val chip =
            LinearLayout(this)

        chip.orientation =
            LinearLayout.HORIZONTAL

        chip.gravity =
            Gravity.CENTER_VERTICAL

        chip.setPadding(
            dpToPx(14),
            dpToPx(10),
            dpToPx(14),
            dpToPx(10)
        )

        chip.setBackgroundResource(
            R.drawable.chip_bg
        )

        val params =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

        params.marginEnd =
            dpToPx(10)

        chip.layoutParams =
            params

        // ========================================================
        // ICON
        // ========================================================

        val icon =
            ImageView(this)

        icon.layoutParams =
            LinearLayout.LayoutParams(
                dpToPx(22),
                dpToPx(22)
            )

        val iconRes =
            getCategoryIconRes(
                category.iconName
            )

        if (iconRes != 0) {

            icon.setImageResource(
                iconRes
            )
        }

        icon.setColorFilter(
            category.tintColor
        )

        // ========================================================
        // TEXT
        // ========================================================

        val text =
            TextView(this)

        val textParams =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

        textParams.marginStart =
            dpToPx(8)

        text.layoutParams =
            textParams

        text.text =
            category.label

        text.textSize =
            14f

        text.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.primary_900
            )
        )

        // ========================================================
        // SELECTED STATE
        // ========================================================

        chip.alpha =
            if (
                selectedCategoryId == null ||
                selectedCategoryId == category.id
            ) {
                1.0f
            } else {
                0.65f
            }

        // ========================================================
        // CLICK
        // ========================================================

        chip.setOnClickListener {

            selectedCategoryId =
                category.id

            selectedCategoryLabel =
                category.label

            selectedCategoryIconRes =
                getCategoryIconRes(
                    category.iconName
                )

            updateSelectedCategoryText()

            updateCategoryChips()
        }

        chip.addView(icon)
        chip.addView(text)

        return chip
    }

    // ============================================================
    // OTHER CATEGORY CHIP
    // ============================================================

    private fun createOtherChip(): LinearLayout {

        val chip =
            LinearLayout(this)

        chip.orientation =
            LinearLayout.HORIZONTAL

        chip.gravity =
            Gravity.CENTER_VERTICAL

        chip.setPadding(
            dpToPx(14),
            dpToPx(10),
            dpToPx(14),
            dpToPx(10)
        )

        chip.setBackgroundResource(
            R.drawable.chip_bg
        )

        val params =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

        params.marginEnd =
            dpToPx(10)

        chip.layoutParams =
            params

        val icon =
            TextView(this)

        icon.text =
            "⋯"

        icon.textSize =
            22f

        val text =
            TextView(this)

        val textParams =
            LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            )

        textParams.marginStart =
            dpToPx(8)

        text.layoutParams =
            textParams

        text.text =
            "Other"

        text.textSize =
            14f

        text.setTextColor(
            ContextCompat.getColor(
                this,
                R.color.primary_900
            )
        )

        chip.addView(icon)
        chip.addView(text)

        return chip
    }

    // ============================================================
    // SELECTED CATEGORY
    // ============================================================

    private fun updateSelectedCategoryText() {

        tvSelectedCategory.text =
            if (selectedCategoryId == null) {

                "No category selected"

            } else {

                "Selected: $selectedCategoryLabel"
            }
    }

    // ============================================================
    // OPEN CATEGORY SELECTOR
    // ============================================================

    private fun openCategorySelector() {

        val intent =
            Intent(
                this,
                SelectCategoryActivity::class.java
            )

        intent.putExtra(
            SelectCategoryActivity.EXTRA_USER_ID,
            currentUserId
        )

        selectCategoryLauncher.launch(
            intent
        )
    }

    // ============================================================
    // LOAD TRANSACTION FOR EDITING
    // ============================================================

    private fun loadTransactionForEditing() {

        lifecycleScope.launch(Dispatchers.IO) {

            val transaction =
                database
                    .transactionDao()
                    .getTransactionById(
                        editingTransactionId,
                        currentUserId
                    )

            if (transaction == null) {

                withContext(Dispatchers.Main) {

                    Toast.makeText(
                        this@AddTransactionActivity,
                        "Transaction not found",
                        Toast.LENGTH_SHORT
                    ).show()

                    finish()
                }

                return@launch
            }

            // ====================================================
            // LOAD BASIC TRANSACTION DATA
            // ====================================================

            withContext(Dispatchers.Main) {

                currentAmountStr =
                    transaction.amount.toString()

                if (
                    currentAmountStr.endsWith(".0")
                ) {

                    currentAmountStr =
                        currentAmountStr
                            .removeSuffix(".0")
                }

                updateAmountDisplay()

                editingCreatedAt =
                    transaction.createdAt

                etNote.setText(
                    transaction.note ?: ""
                )
            }

            // ====================================================
            // NORMAL TRANSACTION
            // ====================================================

            if (
                transaction.type != "TRANSFER_OUT" &&
                transaction.type != "TRANSFER_IN"
            ) {

                withContext(Dispatchers.Main) {

                    isTransfer = false

                    isExpense =
                        transaction.type == "EXPENSE"

                    selectedCategoryId =
                        transaction.categoryId

                    val category =
                        categoryList.firstOrNull {
                            it.id == selectedCategoryId
                        }

                    selectedCategoryLabel =
                        category?.label
                            ?: ""

                    selectedCategoryIconRes =
                        category?.let {

                            getCategoryIconRes(
                                it.iconName
                            )

                        } ?: 0

                    selectedAccountId =
                        transaction.accountId

                    updateTypeUI()

                    updateSelectedCategoryText()
                    updateCategoryChips()
                    updatePaymentChips()
                }

                return@launch
            }

            // ====================================================
            // TRANSFER EDIT
            //
            // Load the COMPLETE transfer pair using the group ID.
            // This allows editing from either TRANSFER_OUT or
            // TRANSFER_IN.
            // ====================================================

            val groupId =
                transaction.transferGroupId

            if (groupId.isNullOrEmpty()) {

                withContext(Dispatchers.Main) {

                    Toast.makeText(
                        this@AddTransactionActivity,
                        "This transfer has no transfer group ID and cannot be edited safely.",
                        Toast.LENGTH_LONG
                    ).show()

                    finish()
                }

                return@launch
            }

            val transferTransactions =
                database
                    .transactionDao()
                    .getTransactionsByTransferGroupId(
                        groupId,
                        currentUserId
                    )

            val transferOut =
                transferTransactions
                    .firstOrNull {
                        it.type == "TRANSFER_OUT"
                    }

            val transferIn =
                transferTransactions
                    .firstOrNull {
                        it.type == "TRANSFER_IN"
                    }

            if (
                transferOut == null ||
                transferIn == null
            ) {

                withContext(Dispatchers.Main) {

                    Toast.makeText(
                        this@AddTransactionActivity,
                        "Complete transfer pair not found.",
                        Toast.LENGTH_LONG
                    ).show()

                    finish()
                }

                return@launch
            }

            // ====================================================
            // LOAD TRANSFER VALUES
            // ====================================================

            withContext(Dispatchers.Main) {

                isExpense = false
                isTransfer = true

                editingTransferGroupId =
                    groupId

                // SOURCE
                selectedAccountId =
                    transferOut.accountId

                // DESTINATION
                selectedDestinationAccountId =
                    transferIn.accountId

                // Use the transfer amount from OUT.
                currentAmountStr =
                    transferOut.amount.toString()

                if (
                    currentAmountStr.endsWith(".0")
                ) {

                    currentAmountStr =
                        currentAmountStr
                            .removeSuffix(".0")
                }

                updateAmountDisplay()

                // Prefer the user's note.
                // If empty, use the transfer OUT note.
                etNote.setText(
                    transferOut.note
                        ?.takeIf { it.isNotBlank() }
                        ?: ""
                )

                updateTypeUI()

                updateDestinationAccountChips()

                updatePaymentChips()
            }
        }
    }

    // ============================================================
    // UPDATE TRANSACTION
    // ============================================================

    private fun updateTransaction() {

        val amount = currentAmountStr.toDoubleOrNull()

        if (amount == null || amount <= 0) {
            Toast.makeText(
                this,
                "Please enter a valid amount",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        if (selectedCategoryId == null) {
            Toast.makeText(
                this,
                "Please select a category",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        if (selectedAccountId == null) {
            Toast.makeText(
                this,
                "Please select an account",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val note = etNote.text.toString().trim()

        val title = if (note.isNotEmpty()) {
            note
        } else {
            selectedCategoryLabel.ifEmpty { "Transaction" }
        }

        val txnType = if (isExpense) {
            "EXPENSE"
        } else {
            "INCOME"
        }

        lifecycleScope.launch {

            try {

                withContext(Dispatchers.IO) {

                    // ====================================================
                    // UPDATE EXISTING TRANSACTION
                    // ====================================================

                    database.transactionDao().updateTransaction(
                        transactionId = editingTransactionId,
                        userId = currentUserId,
                        title = title,
                        amount = amount,
                        type = txnType,
                        categoryId = selectedCategoryId,
                        accountId = selectedAccountId,
                        note = note
                    )

                    // ====================================================
                    // CHECK BUDGETS AFTER EXPENSE UPDATE
                    // ====================================================

                    if (isExpense) {
                        checkBudgetsAfterExpense()
                    }

                    // ====================================================
                    // CREATE UPDATE NOTIFICATION
                    // ====================================================

                    val notification = if (isExpense) {

                        Notification(
                            notificationId = 0,
                            userId = currentUserId,
                            title = "Expense Updated",
                            message = "You updated your expense of $userCurrency ${formatAmount(amount)} on $title ($selectedCategoryLabel).",
                            type = "EXPENSE",
                            referenceType = "EXPENSE",
                            referenceId = editingTransactionId,
                            isRead = false,
                            timeAgo = null,
                            createdAt = System.currentTimeMillis().toString()
                        )

                    } else {

                        Notification(
                            notificationId = 0,
                            userId = currentUserId,
                            title = "Income Updated",
                            message = "You updated your income of $userCurrency ${formatAmount(amount)} from $title.",
                            type = "INCOME",
                            referenceType = "INCOME",
                            referenceId = editingTransactionId,
                            isRead = false,
                            timeAgo = null,
                            createdAt = System.currentTimeMillis().toString()
                        )
                    }

                    database.notificationDao().insertNotification(notification)
                }

                // ========================================================
                // SUCCESS
                // ========================================================

                Toast.makeText(
                    this@AddTransactionActivity,
                    if (isExpense) {
                        "Expense updated successfully!"
                    } else {
                        "Income updated successfully!"
                    },
                    Toast.LENGTH_SHORT
                ).show()

                finish()

            } catch (e: Exception) {

                Toast.makeText(
                    this@AddTransactionActivity,
                    "Failed to update transaction: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // ============================================================
    // UPDATE TRANSFER
    // ============================================================

    private fun updateTransfer() {

        val amount = currentAmountStr.toDoubleOrNull()

        if (amount == null || amount <= 0) {
            Toast.makeText(
                this,
                "Please enter a valid amount",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        if (selectedAccountId == null) {
            Toast.makeText(
                this,
                "Please select source account",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        if (selectedDestinationAccountId == null) {
            Toast.makeText(
                this,
                "Please select destination account",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        if (selectedAccountId == selectedDestinationAccountId) {
            Toast.makeText(
                this,
                "Source and destination accounts must be different",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val transferGroupId = editingTransferGroupId

        if (transferGroupId.isNullOrEmpty()) {
            Toast.makeText(
                this,
                "Transfer information not found",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        lifecycleScope.launch {

            try {

                withContext(Dispatchers.IO) {

                    // ====================================================
                    // GET ORIGINAL TRANSFER PAIR
                    // ====================================================

                    val transferPair =
                        database.transactionDao()
                            .getTransactionsByTransferGroupId(
                                transferGroupId = transferGroupId,
                                userId = currentUserId
                            )

                    if (transferPair.size < 2) {
                        throw Exception("Transfer pair not found")
                    }

                    val oldTransferOut =
                        transferPair.firstOrNull {
                            it.type == "TRANSFER_OUT"
                        }

                    val oldTransferIn =
                        transferPair.firstOrNull {
                            it.type == "TRANSFER_IN"
                        }

                    if (oldTransferOut == null || oldTransferIn == null) {
                        throw Exception("Invalid transfer data")
                    }

                    // ====================================================
                    // GET SOURCE ACCOUNT
                    // ====================================================

                    val sourceAccount =
                        database.accountDao().getAccountById(
                            accountId = selectedAccountId!!,
                            userId = currentUserId
                        )

                    if (sourceAccount == null) {
                        throw Exception("Source account not found")
                    }

                    // ====================================================
                    // GET CURRENT SOURCE ACCOUNT BALANCE
                    // ====================================================

                    val sourceBalance =
                        database.accountDao().getAccountBalanceById(
                            accountId = selectedAccountId!!,
                            userId = currentUserId
                        )

                    if (sourceBalance == null) {
                        throw Exception("Source account balance not found")
                    }

                    /*
                     * If the old transfer used the same source account,
                     * add the old transfer amount back temporarily.
                     *
                     * Example:
                     *
                     * Current balance = 50,000
                     * Old transfer    = 20,000
                     *
                     * Available for editing =
                     * 50,000 + 20,000 = 70,000
                     */

                    val availableBalance =
                        if (oldTransferOut.accountId == selectedAccountId) {
                            sourceBalance.currentBalance + oldTransferOut.amount
                        } else {
                            sourceBalance.currentBalance
                        }

                    // ====================================================
                    // CHECK INSUFFICIENT BALANCE
                    // ====================================================

                    if (availableBalance < amount) {
                        throw Exception(
                            "Insufficient balance. Available: $userCurrency ${
                                formatAmount(availableBalance)
                            }"
                        )
                    }

                    // ====================================================
                    // GET DESTINATION ACCOUNT
                    // ====================================================

                    val destinationAccount =
                        database.accountDao().getAccountById(
                            accountId = selectedDestinationAccountId!!,
                            userId = currentUserId
                        )

                    if (destinationAccount == null) {
                        throw Exception("Destination account not found")
                    }

                    val note = etNote.text.toString().trim()

                    // ====================================================
                    // UPDATE TRANSFER OUT
                    // ====================================================

                    val updatedTransferOut =
                        oldTransferOut.copy(
                            amount = amount,
                            accountId = selectedAccountId!!,
                            note = note,
                            createdAt = editingCreatedAt
                        )

                    // ====================================================
                    // UPDATE TRANSFER IN
                    // ====================================================

                    val updatedTransferIn =
                        oldTransferIn.copy(
                            amount = amount,
                            accountId = selectedDestinationAccountId!!,
                            note = note,
                            createdAt = editingCreatedAt
                        )

                    // ====================================================
                    // UPDATE COMPLETE TRANSFER
                    // ====================================================

                    database.transactionDao().updateTransfer(
                        updatedTransferOut,
                        updatedTransferIn
                    )

                    // ====================================================
                    // CREATE "TRANSFER UPDATED" NOTIFICATION
                    // ====================================================

                    val notification = Notification(
                        notificationId = 0,
                        userId = currentUserId,
                        title = "Transfer Updated",
                        message = "You updated a transfer of $userCurrency ${
                            formatAmount(amount)
                        } from ${sourceAccount.name} to ${destinationAccount.name}.",
                        type = "TRANSFER",
                        referenceType = "TRANSFER",
                        referenceId = null,
                        isRead = false,
                        timeAgo = null,
                        createdAt = System.currentTimeMillis().toString()
                    )

                    database.notificationDao().insertNotification(
                        notification
                    )
                }

                // ========================================================
                // SUCCESS
                // ========================================================

                Toast.makeText(
                    this@AddTransactionActivity,
                    "Transfer updated successfully!",
                    Toast.LENGTH_SHORT
                ).show()

                finish()

            } catch (e: Exception) {

                Toast.makeText(
                    this@AddTransactionActivity,
                    "Failed to update transfer: ${e.message}",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    // ============================================================
    // SAVE EXPENSE / INCOME
    // ============================================================

    private fun saveTransactionAndNotify() {

        val amount =
            currentAmountStr.toDoubleOrNull()

        if (
            amount == null ||
            amount <= 0
        ) {

            Toast.makeText(
                this,
                "Please enter an amount greater than 0",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        if (selectedCategoryId == null) {

            Toast.makeText(
                this,
                "Please select a category",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        if (selectedAccountId == null) {

            Toast.makeText(
                this,
                "Please select a payment account",
                Toast.LENGTH_SHORT
            ).show()

            return
        }

        val note =
            etNote.text
                .toString()
                .trim()

        val title =
            if (note.isNotEmpty()) {
                note
            } else {
                selectedCategoryLabel
            }

        val txnType =
            if (isExpense) {
                "EXPENSE"
            } else {
                "INCOME"
            }

        lifecycleScope.launch(Dispatchers.IO) {

            try {

                val transaction =
                    Transaction(

                        transactionId = 0,

                        userId =
                            currentUserId,

                        title =
                            title,

                        amount =
                            amount,

                        type =
                            txnType,

                        categoryId =
                            selectedCategoryId,

                        accountId =
                            selectedAccountId,

                        note =
                            note.ifEmpty {
                                null
                            },

                        createdAt =
                            System.currentTimeMillis(),

                        transferGroupId =
                            null
                    )

                database
                    .transactionDao()
                    .insertTransaction(
                        transaction
                    )

                // ========================================================
                // CHECK ALL BUDGETS
                // ========================================================

                if (isExpense) {
                    checkBudgetsAfterExpense()
                }

                val notiTitle: String
                val notiMessage: String
                val notiType: String

                if (isExpense) {

                    if (amount >= 50000) {

                        notiTitle =
                            "Large transaction detected"

                        notiMessage =
                            "A $userCurrency $amount charge was made for $title today."

                        notiType =
                            "TRANSACTION"

                    } else {

                        notiTitle =
                            "Expense Added"

                        notiMessage =
                            "You spent $userCurrency $amount on $title ($selectedCategoryLabel)."

                        notiType =
                            "EXPENSE"
                    }

                } else {

                    notiTitle =
                        "Income Received"

                    notiMessage =
                        "You received $userCurrency $amount from $title."

                    notiType =
                        "INCOME"
                }

                val notification =
                    Notification(

                        notificationId = 0,

                        userId =
                            currentUserId,

                        title =
                            notiTitle,

                        message =
                            notiMessage,

                        type =
                            notiType,

                        referenceType =
                            txnType,

                        referenceId =
                            null,

                        isRead =
                            false,

                        timeAgo =
                            null,

                        createdAt =
                            System.currentTimeMillis()
                                .toString()
                    )

                database
                    .notificationDao()
                    .insertNotification(
                        notification
                    )

                withContext(Dispatchers.Main) {

                    Toast.makeText(
                        this@AddTransactionActivity,

                        if (isExpense) {
                            "Expense saved successfully!"
                        } else {
                            "Income saved successfully!"
                        },

                        Toast.LENGTH_SHORT
                    ).show()

                    finish()
                }

            } catch (e: Exception) {

                e.printStackTrace()

                withContext(Dispatchers.Main) {

                    Toast.makeText(
                        this@AddTransactionActivity,
                        "Error saving transaction: ${e.localizedMessage}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    // ============================================================
// CHECK BUDGETS AFTER EXPENSE
//
// Checks:
// 1. Overall budget amount
// 2. Every category budget inside every active budget
//
// A notification is created only when spending crosses the
// budget limit for the first time.
// ============================================================

    private suspend fun checkBudgetsAfterExpense() {

        // Only expenses affect budgets.
        if (!isExpense) {
            return
        }

        val now =
            System.currentTimeMillis()

        // ========================================================
        // GET ALL ACTIVE BUDGETS
        // ========================================================

        val activeBudgets =
            database
                .budgetDao()
                .getActiveBudgets(
                    currentUserId,
                    now
                )

        // No active budgets.
        if (activeBudgets.isEmpty()) {
            return
        }

        // ========================================================
        // CHECK EVERY BUDGET CARD
        // ========================================================

        for (budget in activeBudgets) {

            // ====================================================
            // OVERALL BUDGET SPENDING
            // ====================================================

            val totalSpent =
                database
                    .transactionDao()
                    .getBudgetExpense(
                        userId = currentUserId,
                        startDate = budget.startDate,
                        endDate = budget.endDate
                    )

            // ====================================================
            // OVERALL BUDGET EXCEEDED
            // ====================================================

            if (totalSpent > budget.amount) {

                val existingNotificationCount =
                    database
                        .notificationDao()
                        .countBudgetExceededNotification(
                            userId = currentUserId,
                            budgetId = budget.budgetId
                        )

                // Only create one notification.
                if (existingNotificationCount == 0) {

                    val notification =
                        Notification(

                            notificationId = 0,

                            userId =
                                currentUserId,

                            title =
                                "Budget Exceeded",

                            message =
                                "${budget.name}: You have spent " +
                                        "$userCurrency ${formatAmount(totalSpent)} " +
                                        "of your $userCurrency ${formatAmount(budget.amount)} budget.",

                            type =
                                "BUDGET_EXCEEDED",

                            referenceType =
                                "BUDGET",

                            referenceId =
                                budget.budgetId,

                            isRead =
                                false,

                            timeAgo =
                                null,

                            createdAt =
                                System.currentTimeMillis()
                                    .toString()
                        )

                    database
                        .notificationDao()
                        .insertNotification(
                            notification
                        )
                }
            }

            // ====================================================
            // GET ALL CATEGORY LIMITS FOR THIS BUDGET
            // ====================================================

            val budgetCategories =
                database
                    .budgetDao()
                    .getBudgetCategoriesOnce(
                        budget.budgetId
                    )

            // ====================================================
            // CHECK EVERY CATEGORY
            // ====================================================

            for (budgetCategory in budgetCategories) {

                val categorySpent =
                    database
                        .transactionDao()
                        .getCategoryExpenseForPeriod(
                            userId = currentUserId,

                            categoryId =
                                budgetCategory.categoryId,

                            startDate =
                                budget.startDate,

                            endDate =
                                budget.endDate
                        )

                // =================================================
                // CATEGORY BUDGET EXCEEDED
                // =================================================

                if (
                    categorySpent >
                    budgetCategory.limitAmount
                ) {

                    val existingNotificationCount =
                        database
                            .notificationDao()
                            .countCategoryBudgetExceededNotification(
                                userId =
                                    currentUserId,

                                budgetCategoryId =
                                    budgetCategory.budgetCategoryId
                            )

                    // Only create one notification.
                    if (
                        existingNotificationCount == 0
                    ) {

                        val category =
                            database
                                .categoryDao()
                                .getCategoryById(
                                    categoryId = budgetCategory.categoryId,
                                    userId = currentUserId
                                )

                        val categoryName =
                            category?.label ?: "Category"

                        val notification =
                            Notification(

                                notificationId = 0,

                                userId =
                                    currentUserId,

                                title =
                                    "$categoryName Budget Exceeded",

                                message =
                                    "You have spent " +
                                            "$userCurrency ${formatAmount(categorySpent)} " +
                                            "on $categoryName, exceeding your " +
                                            "$userCurrency ${formatAmount(budgetCategory.limitAmount)} category budget.",

                                type =
                                    "CATEGORY_BUDGET_EXCEEDED",

                                referenceType =
                                    "BUDGET_CATEGORY",

                                referenceId =
                                    budgetCategory.budgetCategoryId,

                                isRead =
                                    false,

                                timeAgo =
                                    null,

                                createdAt =
                                    System.currentTimeMillis()
                                        .toString()
                            )

                        database
                            .notificationDao()
                            .insertNotification(
                                notification
                            )
                    }
                }
            }
        }
    }

    // ============================================================
    // CUSTOM KEYPAD
    // ============================================================

    private fun setupCustomKeypad() {

        val numKeys =
            listOf(
                R.id.key0 to "0",
                R.id.key1 to "1",
                R.id.key2 to "2",
                R.id.key3 to "3",
                R.id.key4 to "4",
                R.id.key5 to "5",
                R.id.key6 to "6",
                R.id.key7 to "7",
                R.id.key8 to "8",
                R.id.key9 to "9"
            )

        numKeys.forEach { (id, digit) ->

            findViewById<View>(
                id
            ).setOnClickListener {

                if (
                    currentAmountStr.length < 9
                ) {

                    currentAmountStr +=
                        digit

                    updateAmountDisplay()
                }
            }
        }

        findViewById<View>(
            R.id.keyDot
        ).setOnClickListener {

            if (
                !currentAmountStr.contains(".") &&
                currentAmountStr.isNotEmpty()
            ) {

                currentAmountStr += "."

                updateAmountDisplay()
            }
        }

        findViewById<View>(
            R.id.keyDel
        ).setOnClickListener {

            if (
                currentAmountStr.isNotEmpty()
            ) {

                currentAmountStr =
                    currentAmountStr.dropLast(1)

                updateAmountDisplay()
            }
        }
    }

    // ============================================================
    // AMOUNT DISPLAY
    // ============================================================

    private fun updateAmountDisplay() {

        tvAmount.setText(
            if (currentAmountStr.isEmpty()) {
                "$userCurrency 0"
            } else {
                "$userCurrency $currentAmountStr"
            }
        )

        // Put the cursor at the END of the amount
        tvAmount.setSelection(tvAmount.text.length)
    }

    private fun formatAmount(
        amount: Double
    ): String {

        return if (amount % 1.0 == 0.0) {
            amount.toLong().toString()
        } else {
            String.format(
                "%.2f",
                amount
            )
        }
    }

    // ============================================================
    // DP → PX
    // ============================================================

    private fun dpToPx(
        dp: Int
    ): Int {

        return (
                dp *
                        resources
                            .displayMetrics
                            .density
                ).toInt()
    }
}

